import { OpportunityDashboard } from "@/components/opportunity-dashboard"

export default function OportunidadesPage() {
  return (
    <main style={{ padding: 0, width: "100%", maxWidth: "100%" }}>
      <OpportunityDashboard />
    </main>
  )
}

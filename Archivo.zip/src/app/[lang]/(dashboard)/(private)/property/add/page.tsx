// Component Imports
import CreateDeal from '@/views/property/add'

const CreateDealPage = () => {
  return <CreateDeal />
}

export default CreateDealPage

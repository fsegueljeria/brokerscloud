import { ProspectDashboard } from "@/components/prospect-dashboard"

export default function ProspectosPage() {
  return (
    <main style={{ padding: 0, width: "100%", maxWidth: "100%" }}>
      <ProspectDashboard />
    </main>
  )
}

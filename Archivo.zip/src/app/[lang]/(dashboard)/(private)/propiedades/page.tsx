import { PropertyDashboard } from "@/components/property-dashboard"

export default function PropiedadesPage() {
  return (
    <main style={{ padding: 0, width: "100%", maxWidth: "100%" }}>
      <PropertyDashboard />
    </main>
  )
}

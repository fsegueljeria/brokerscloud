"use client"

import { VisitDashboard } from "@/components/visit-dashboard"

export default function VisitasPage() {
  return <VisitDashboard />
}
